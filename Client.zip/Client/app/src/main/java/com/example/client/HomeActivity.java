package com.example.client;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    private EditText sugar;
    private EditText rice;
    private EditText biscuit;
    private EditText milk;
    private EditText diarymilk;
    private EditText pepsi;
    private TextView amount_sugar;
    int res;
    private Button btn;
    private Button pay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

pay = findViewById(R.id.pay);
        sugar = findViewById(R.id.sugar);
        rice = findViewById(R.id.rice);
        biscuit = findViewById(R.id.biscuit);
        milk = findViewById(R.id.milk);
        diarymilk = findViewById(R.id.diarymilk);
        pepsi = findViewById(R.id.pepsi);
        amount_sugar = findViewById(R.id.textView);

        btn = findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                int msugar;
                int mrice;
                int mbiscuit;
                int mmilk;
                int mdiarymilk;
                int mpepsi;


                msugar = Integer.parseInt(sugar.getText().toString());
                mrice = Integer.parseInt(rice.getText().toString());
                mbiscuit = Integer.parseInt(biscuit.getText().toString());
                mmilk = Integer.parseInt(milk.getText().toString());
                mdiarymilk = Integer.parseInt(diarymilk.getText().toString());
                mpepsi = Integer.parseInt(pepsi.getText().toString());


                int asugar = msugar*35;
                int arice = mrice*50;
                int abiscuit = mbiscuit*10;
                int amilk = mmilk*25;
                int adiarymilk = mdiarymilk*20;
                int apepsi = mpepsi*45;
                int res = asugar + arice + abiscuit + amilk + adiarymilk + apepsi;

                amount_sugar.setText(Integer.toString(res));



            }
        });

pay.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        startActivity(new Intent(HomeActivity.this,PayActivity.class));
    }
});
    }
}

